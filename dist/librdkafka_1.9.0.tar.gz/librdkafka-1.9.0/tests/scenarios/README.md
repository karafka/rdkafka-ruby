# Test scenarios

A test scenario defines the trivup Kafka cluster setup.

The scenario name is the name of the file (without .json extension)
and the contents is the trivup configuration dict.
