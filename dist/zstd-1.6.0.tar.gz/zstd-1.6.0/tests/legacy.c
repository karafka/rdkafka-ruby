/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

/*
    This program uses hard-coded data compressed with Zstd legacy versions
    and tests that the API decompresses them correctly
*/

/*===========================================
*   Dependencies
*==========================================*/
#include <stddef.h>              /* size_t */
#include <stdlib.h>              /* malloc, free */
#include <stdio.h>               /* fprintf */
#include <string.h>              /* strlen, memcpy, memcmp */
#define ZSTD_STATIC_LINKING_ONLY /* ZSTD_decompressBound */
#include "zstd.h"
#include "zstd_errors.h"

/* Same normalization as lib/legacy/zstd_legacy.h :
 * no legacy support means only the current format can be decoded */
#if !defined(ZSTD_LEGACY_SUPPORT) || (ZSTD_LEGACY_SUPPORT == 0)
#  undef ZSTD_LEGACY_SUPPORT
#  define ZSTD_LEGACY_SUPPORT 8
#endif

/*===========================================
*   Macros
*==========================================*/
#define DISPLAY(...)          fprintf(stderr, __VA_ARGS__)

/*===========================================
*   Precompressed frames
*==========================================*/
/* Each frame below is the "BLOCK" text, compressed with default settings by
 * the last release able to produce that format version.
 * A frame produced by v0.N is only decodable when ZSTD_LEGACY_SUPPORT <= N,
 * hence the test adapts itself to the level it has been compiled with.
 */
#define FRAME_V01_SIZE 189
#define FRAME_V02_SIZE 187
#define FRAME_V03_SIZE 187
#define FRAME_V04_SIZE 198
#define FRAME_V05_SIZE 184
#define FRAME_V06_SIZE 178
#define FRAME_V07_SIZE 178
#define FRAME_V08_SIZE 179
#define ALL_FRAMES_SIZE (FRAME_V01_SIZE + FRAME_V02_SIZE + FRAME_V03_SIZE + FRAME_V04_SIZE + FRAME_V05_SIZE + FRAME_V06_SIZE + FRAME_V07_SIZE + FRAME_V08_SIZE)

const char* const FRAME_V01;   /* content is at end of file, produced by v0.1.1 */
const char* const FRAME_V02;   /* content is at end of file, produced by v0.2.2 */
const char* const FRAME_V03;   /* content is at end of file, produced by v0.3.6 */
const char* const FRAME_V04;   /* content is at end of file, produced by v0.4.3 */
const char* const FRAME_V05;   /* content is at end of file, produced by v0.5.0 */
const char* const FRAME_V06;   /* content is at end of file, produced by v0.6.0 */
const char* const FRAME_V07;   /* content is at end of file, produced by v0.7.0 */
const char* const FRAME_V08;   /* content is at end of file, produced by v0.8.0 */
const char* const BLOCK;      /* content is at end of file */


/* legacy formats older than v0.4 only offer a single-shot decoder :
 * ZSTD_decompressStream() answers version_unsupported on such frames
 * (see ZSTD_initLegacyStream() in lib/legacy/zstd_legacy.h) */
#define OLDEST_STREAMABLE_VERSION 4

/* buildTestFrames() :
 * concatenates, oldest first, the frames this build is able to decode,
 * skipping those older than @fromVersion.
 * @dst must be at least ALL_FRAMES_SIZE bytes long.
 * @return : nb of frames written; *cSize receives their total size */
static unsigned buildTestFrames(char* dst, size_t* cSize, int fromVersion)
{
    unsigned nbFrames = 0;
    size_t pos = 0;

#define ADD_FRAME(n, v)                                     \
    if (fromVersion <= (n)) {                               \
        memcpy(dst + pos, FRAME_V##v, FRAME_V##v##_SIZE);   \
        pos += FRAME_V##v##_SIZE;                           \
        nbFrames++;                                         \
    }

#if (ZSTD_LEGACY_SUPPORT <= 1)
    ADD_FRAME(1, 01)
#endif
#if (ZSTD_LEGACY_SUPPORT <= 2)
    ADD_FRAME(2, 02)
#endif
#if (ZSTD_LEGACY_SUPPORT <= 3)
    ADD_FRAME(3, 03)
#endif
#if (ZSTD_LEGACY_SUPPORT <= 4)
    ADD_FRAME(4, 04)
#endif
#if (ZSTD_LEGACY_SUPPORT <= 5)
    ADD_FRAME(5, 05)
#endif
#if (ZSTD_LEGACY_SUPPORT <= 6)
    ADD_FRAME(6, 06)
#endif
#if (ZSTD_LEGACY_SUPPORT <= 7)
    ADD_FRAME(7, 07)
#endif
    ADD_FRAME(8, 08)
#undef ADD_FRAME

    *cSize = pos;
    return nbFrames;
}


static int testSimpleAPI(const char* compressed, size_t compressedSize,
                         const char* expected, size_t expectedSize)
{
    char* const output = malloc(expectedSize);

    if (!output) {
        DISPLAY("ERROR: Not enough memory!\n");
        return 1;
    }

    {
        size_t const ret = ZSTD_decompress(output, expectedSize, compressed, compressedSize);
        if (ZSTD_isError(ret)) {
            if (ret == ZSTD_error_prefix_unknown) {
                DISPLAY("ERROR: Invalid frame magic number, was this compiled "
                        "without legacy support?\n");
            } else {
                DISPLAY("ERROR: %s\n", ZSTD_getErrorName(ret));
            }
            free(output);
            return 1;
        }
        if (ret != expectedSize) {
            DISPLAY("ERROR: Wrong decoded size\n");
            free(output);
            return 1;
        }
    }
    if (memcmp(expected, output, expectedSize) != 0) {
        DISPLAY("ERROR: Wrong decoded output produced\n");
        free(output);
        return 1;
    }

    free(output);
    DISPLAY("Simple API OK\n");
    return 0;
}


static int testStreamingAPI(const char* compressed, size_t compressedSize,
                            const char* expected, size_t expectedSize)
{
    int error_code = 0;
    size_t const outBuffSize = ZSTD_DStreamOutSize();
    char* const outBuff = malloc(outBuffSize);
    ZSTD_DStream* const stream = ZSTD_createDStream();
    ZSTD_inBuffer input = { NULL, 0, 0 };
    size_t outputPos = 0;
    int needsInit = 1;

    input.src = compressed;
    input.size = compressedSize;

    if (outBuff == NULL) {
        DISPLAY("ERROR: Could not allocate memory\n");
        return 1;
    }
    if (stream == NULL) {
        DISPLAY("ERROR: Could not create dstream\n");
        free(outBuff);
        return 1;
    }

    while (1) {
        ZSTD_outBuffer output = {outBuff, outBuffSize, 0};
        if (needsInit) {
            size_t const ret = ZSTD_initDStream(stream);
            if (ZSTD_isError(ret)) {
                DISPLAY("ERROR: ZSTD_initDStream: %s\n", ZSTD_getErrorName(ret));
                error_code = 1;
                break;
        }   }

        {   size_t const ret = ZSTD_decompressStream(stream, &output, &input);
            if (ZSTD_isError(ret)) {
                DISPLAY("ERROR: ZSTD_decompressStream: %s\n", ZSTD_getErrorName(ret));
                error_code = 1;
                break;
            }

            if (ret == 0) {
                needsInit = 1;
        }   }

        if (outputPos + output.pos > expectedSize) {
            DISPLAY("ERROR: Decoded more than expected\n");
            error_code = 1;
            break;
        }
        if (memcmp(outBuff, expected + outputPos, output.pos) != 0) {
            DISPLAY("ERROR: Wrong decoded output produced\n");
            error_code = 1;
            break;
        }
        outputPos += output.pos;
        if (input.pos == input.size && output.pos < output.size) {
            break;
        }
    }

    if (error_code == 0 && outputPos != expectedSize) {
        DISPLAY("ERROR: Decoded less than expected\n");
        error_code = 1;
    }

    free(outBuff);
    ZSTD_freeDStream(stream);
    if (error_code == 0) DISPLAY("Streaming API OK\n");
    return error_code;
}

static int testFrameDecoding(const char* compressed, size_t compressedSize,
                             size_t expectedSize)
{
    if (expectedSize > ZSTD_decompressBound(compressed, compressedSize)) {
        DISPLAY("ERROR: ZSTD_decompressBound: decompressed bound too small\n");
        return 1;
    }
    {   const char* ip = compressed;
        size_t remainingSize = compressedSize;
        while (1) {
            size_t frameSize = ZSTD_findFrameCompressedSize(ip, remainingSize);
            if (ZSTD_isError(frameSize)) {
                DISPLAY("ERROR: ZSTD_findFrameCompressedSize: %s\n", ZSTD_getErrorName(frameSize));
                return 1;
            }
            if (frameSize > remainingSize) {
                DISPLAY("ERROR: ZSTD_findFrameCompressedSize: expected frameSize to align with src buffer");
                return 1;
            }
            ip += frameSize;
            remainingSize -= frameSize;
            if (remainingSize == 0) break;
        }
    }
    DISPLAY("Frame Decoding OK\n");
    return 0;
}

static int testDecompressBoundConcatenation(const char* compressed, size_t compressedSize)
{
    static const unsigned char frame[16] = {
        0x28, 0xB5, 0x2F, 0xFD, 0xE0,
        0, 0, 0, 0, 0, 0, 0, 0,
        0x01, 0x00, 0x00
    };
    unsigned char combined[sizeof(frame) + ALL_FRAMES_SIZE];
    unsigned long long const maxBound = ZSTD_CONTENTSIZE_ERROR - 1;
    /* The tail exercises the estimators for the actual enabled frame
     * generations, including legacy formats when supported. */
    unsigned long long const tailBound = ZSTD_decompressBound(compressed, compressedSize);
    unsigned delta;
    /* Test the last representable sum and the first rejected sum. The tail
     * must be nonempty so each leading frame is itself representable. */
    if (tailBound == 0 || tailBound > maxBound) {
        DISPLAY("ERROR: Legacy frame bound %llu is outside [1, %llu]\n",
                tailBound, maxBound);
        return 1;
    }
    memcpy(combined, frame, sizeof(frame));
    memcpy(combined + sizeof(frame), compressed, compressedSize);
    for (delta = 0; delta < 2; ++delta) {
        unsigned long long const headSize = maxBound - tailBound + delta;
        unsigned long long const expected = delta == 0 ? maxBound : ZSTD_CONTENTSIZE_ERROR;
        unsigned i;
        for (i = 0; i < 8; ++i)
            combined[5 + i] = (unsigned char)(headSize >> (8 * i));
        if (ZSTD_decompressBound(combined, sizeof(frame) + compressedSize) != expected) {
            DISPLAY("ERROR: ZSTD_decompressBound accepted an unrepresentable concatenated bound\n");
            return 1;
        }
    }
    DISPLAY("Legacy bound concatenation OK\n");
    return 0;
}

static int testDictionaryAPI(unsigned version,
                             const char* compressed, size_t compressedSize,
                             const void* dict, size_t dictSize)
{
    size_t const expectedSize = strlen(BLOCK);
    char* const decoded = malloc(expectedSize);
    ZSTD_DCtx* const dctx = ZSTD_createDCtx();
    ZSTD_inBuffer input = { compressed, compressedSize, 0 };
    ZSTD_outBuffer output = { decoded, expectedSize, 0 };
    size_t ret;
    int result = 1;

    if (decoded == NULL || dctx == NULL) {
        DISPLAY("ERROR: Not enough memory!\n");
        goto cleanup;
    }

    ret = ZSTD_decompress_usingDict(dctx, decoded, expectedSize,
                                    compressed, compressedSize, dict, dictSize);
    if (ZSTD_isError(ret)) {
        DISPLAY("ERROR: ZSTD_decompress_usingDict: %s\n", ZSTD_getErrorName(ret));
        goto cleanup;
    }
    if (ret != expectedSize || memcmp(decoded, BLOCK, expectedSize) != 0) {
        DISPLAY("ERROR: Wrong decoded output with dictionary\n");
        goto cleanup;
    }

    /* Formats older than v0.4 have no streaming decoder. */
    if (version < OLDEST_STREAMABLE_VERSION) {
        result = 0;
        goto cleanup;
    }

    ret = ZSTD_DCtx_reset(dctx, ZSTD_reset_session_and_parameters);
    if (ZSTD_isError(ret)) goto error;
    /* Keep the exact-sized allocation visible to ASan. */
    ret = ZSTD_DCtx_loadDictionary_byReference(dctx, dict, dictSize);
    if (ZSTD_isError(ret)) goto error;
    do {
        size_t const oldInputPos = input.pos;
        size_t const oldOutputPos = output.pos;
        ret = ZSTD_decompressStream(dctx, &output, &input);
        if (ZSTD_isError(ret)) goto error;
        if (ret != 0 && input.pos == oldInputPos && output.pos == oldOutputPos) {
            DISPLAY("ERROR: Dictionary stream made no progress\n");
            goto cleanup;
        }
    } while (ret != 0);
    if (input.pos != input.size || output.pos != expectedSize
        || memcmp(decoded, BLOCK, expectedSize) != 0) {
        DISPLAY("ERROR: Wrong streaming output with dictionary\n");
        goto cleanup;
    }
    result = 0;
    goto cleanup;

error:
    DISPLAY("ERROR: Dictionary streaming API: %s\n", ZSTD_getErrorName(ret));
cleanup:
    ZSTD_freeDCtx(dctx);
    free(decoded);
    return result;
}

static int testLegacyDictionaries(void)
{
    struct {
        unsigned version;
        const char* data;
        size_t size;
    } const frames[] = {
#if (ZSTD_LEGACY_SUPPORT <= 1)
        { 1, FRAME_V01, FRAME_V01_SIZE },
#endif
#if (ZSTD_LEGACY_SUPPORT <= 2)
        { 2, FRAME_V02, FRAME_V02_SIZE },
#endif
#if (ZSTD_LEGACY_SUPPORT <= 3)
        { 3, FRAME_V03, FRAME_V03_SIZE },
#endif
#if (ZSTD_LEGACY_SUPPORT <= 4)
        { 4, FRAME_V04, FRAME_V04_SIZE },
#endif
#if (ZSTD_LEGACY_SUPPORT <= 5)
        { 5, FRAME_V05, FRAME_V05_SIZE },
#endif
#if (ZSTD_LEGACY_SUPPORT <= 6)
        { 6, FRAME_V06, FRAME_V06_SIZE },
#endif
#if (ZSTD_LEGACY_SUPPORT <= 7)
        { 7, FRAME_V07, FRAME_V07_SIZE },
#endif
        { 8, FRAME_V08, FRAME_V08_SIZE }
    };
    size_t f;

    for (f = 0; f < sizeof(frames) / sizeof(frames[0]); ++f) {
        unsigned pattern;
        for (pattern = 0; pattern < 2; ++pattern) {
            unsigned char dictContent[8] = { 0x37, 0xA4, 0x30, 0xEC, 0, 0, 0, 0 };
            size_t maxSize = sizeof(dictContent);
            size_t dictSize;
            if (pattern == 0) {
                memset(dictContent, 'A', sizeof(dictContent));
            } else {
                /* v0.5 and v0.6 have a four-byte magic, while v0.7
                 * also has a four-byte dictionary ID. Every truncated
                 * header must be treated as raw dictionary content.
                 * For v0.5 and v0.6, sizes 4 to 8 keep the magic but
                 * truncate the entropy tables, which must not be read
                 * past their end. v0.7 stops at 7: from 8 bytes, its
                 * magic is parsed as a zstd dictionary. */
                if (frames[f].version < 5 || frames[f].version > 7) continue;
                dictContent[0] = (unsigned char)(0x30 + frames[f].version);
                maxSize = frames[f].version == 7 ? 7 : 8;
            }
            for (dictSize = 0; dictSize <= maxSize; ++dictSize) {
                void* const dict = malloc(dictSize == 0 ? 1 : dictSize);
                int failed;
                if (dict == NULL) {
                    DISPLAY("ERROR: Not enough memory!\n");
                    return 1;
                }
                memcpy(dict, dictContent, dictSize);
                failed = testDictionaryAPI(frames[f].version,
                                           frames[f].data, frames[f].size,
                                           dict, dictSize);
                free(dict);
                if (failed) {
                    DISPLAY("ERROR: v0.%u dictionary of size %u, pattern %u\n",
                            frames[f].version, (unsigned)dictSize, pattern);
                    return 1;
                }
            }
        }
    }
    DISPLAY("Legacy dictionary API OK\n");
    return 0;
}

#if (ZSTD_LEGACY_SUPPORT <= 7)
static int testMultipleDDicts(void)
{
    size_t const blockSize = strlen(BLOCK);
    char* const output = malloc(2 * blockSize);
    ZSTD_DCtx* const dctx = ZSTD_createDCtx();
    ZSTD_DDict* const empty = ZSTD_createDDict(NULL, 0);
    char frames[FRAME_V08_SIZE + FRAME_V07_SIZE];
    int result = 1;
    size_t ret;

    do {
        ZSTD_inBuffer input = {FRAME_V07, FRAME_V07_SIZE, 0};
        ZSTD_outBuffer out = {output, 2 * blockSize, 0};
        if (output == NULL || dctx == NULL || empty == NULL) break;
        if (ZSTD_isError(ZSTD_DCtx_setParameter(dctx, ZSTD_d_refMultipleDDicts, 1))) break;
        if (ZSTD_isError(ZSTD_DCtx_refDDict(dctx, empty))) break;

        ret = ZSTD_decompressDCtx(dctx, output, 2 * blockSize, FRAME_V07, FRAME_V07_SIZE);
        if (ZSTD_getErrorCode(ret) != ZSTD_error_parameter_unsupported) break;
        if (ZSTD_isError(ZSTD_DCtx_reset(dctx, ZSTD_reset_session_only))) break;
        ret = ZSTD_decompressStream(dctx, &out, &input);
        if (ZSTD_getErrorCode(ret) != ZSTD_error_parameter_unsupported) break;
        if (ZSTD_isError(ZSTD_DCtx_reset(dctx, ZSTD_reset_session_only))) break;

        /* A preceding modern frame must not supply an implicit dictionary to
         * the legacy frame. Explicit dictionaries remain supported. */
        memcpy(frames, FRAME_V08, FRAME_V08_SIZE);
        memcpy(frames + FRAME_V08_SIZE, FRAME_V07, FRAME_V07_SIZE);
        ret = ZSTD_decompressDCtx(dctx, output, 2 * blockSize, frames, sizeof(frames));
        if (ZSTD_getErrorCode(ret) != ZSTD_error_parameter_unsupported) break;
        ret = ZSTD_decompress_usingDDict(dctx, output, 2 * blockSize,
                                         frames, sizeof(frames), empty);
        if (ret != 2 * blockSize || memcmp(output, BLOCK, blockSize) != 0
            || memcmp(output + blockSize, BLOCK, blockSize) != 0) break;
        ret = ZSTD_decompress_usingDict(dctx, output, 2 * blockSize,
                                        FRAME_V07, FRAME_V07_SIZE, NULL, 0);
        if (ret != blockSize || memcmp(output, BLOCK, blockSize) != 0) break;
        result = 0;
    } while (0);

    free(output);
    ZSTD_freeDCtx(dctx);
    ZSTD_freeDDict(empty);
    DISPLAY("Multi-DDict legacy boundary %s\n", result ? "FAILED" : "OK");
    return result;
}
#endif

#if (ZSTD_LEGACY_SUPPORT <= 2)
/* Build a real v0.1/v0.2 frame with optional raw history, raw literals, and
 * caller-supplied sequence headers/bitstream. The two versions use different
 * frame magic and literal headers, but the sequence encoding is identical.
 * This deliberately tiny encoder writes only the low byte of each size field.
 * Return 0 rather than silently truncating an unsupported size. */
static size_t buildLegacyOffsetFrame(unsigned char* dst, size_t dstCapacity,
                                     unsigned version,
                                     unsigned prefixSize, unsigned litSize,
                                     const unsigned char* sequences, size_t seqSize)
{
    size_t pos = 4;
    size_t blockHeader;
    size_t payloadSize;
    size_t prefixBlockSize;
    if ((version != 1 && version != 2) || prefixSize > 255 || litSize > 252
        || (version == 2 && litSize >= 64)
        || seqSize > 255 - 3 - litSize) {
        return 0;
    }
    payloadSize = 3 + litSize + seqSize;
    prefixBlockSize = prefixSize == 0 ? 0 : 3 + prefixSize;
    if (dstCapacity < 4 + prefixBlockSize + 3 + payloadSize + 3) return 0;
    if (version == 1) {
        dst[0] = 0xFD; dst[1] = 0x2F; dst[2] = 0xB5; dst[3] = 0x1E;
    } else {
        dst[0] = 0x22; dst[1] = 0xB5; dst[2] = 0x2F; dst[3] = 0xFD;
    }
    if (prefixSize != 0) {
        dst[pos++] = 0x40; dst[pos++] = 0; dst[pos++] = (unsigned char)prefixSize;
        memset(dst + pos, 'P', prefixSize);
        pos += prefixSize;
    }
    blockHeader = pos;
    pos += 3;
    if (version == 1) {
        dst[pos++] = 0x40; dst[pos++] = 0; dst[pos++] = (unsigned char)litSize;
    } else {
        /* v0.2: LE24 (literal size << 2) | raw type 1. The size limit
         * above keeps both high bytes zero. */
        dst[pos++] = (unsigned char)((litSize << 2) | 1);
        dst[pos++] = 0; dst[pos++] = 0;
    }
    memset(dst + pos, 'A', litSize);
    pos += litSize;
    memcpy(dst + pos, sequences, seqSize);
    pos += seqSize;
    dst[blockHeader] = 0;
    dst[blockHeader + 1] = 0;
    dst[blockHeader + 2] = (unsigned char)payloadSize;
    dst[pos++] = 0xC0; dst[pos++] = 0; dst[pos++] = 0;
    return pos;
}
#endif

static int testLegacyZeroOffsets(void)
{
#if (ZSTD_LEGACY_SUPPORT <= 2)
    /* Sequence section: LE16 nbSeq, table modes, one-byte dumps length,
     * serialized table symbols, then the reverse bitstream.
     * 0xA8 selects RLE LL/offset/ML tables, whose symbols follow in that order.
     * 0x98 selects RLE LL/ML and a raw offset table, so only LL/ML symbols are
     * stored before the bitstream. That bitstream can switch offset symbols
     * from explicit distance 1 to the historical repeat code 0. ML code 4
     * means an eight-byte match. */
    static const unsigned char firstZero[] = { 1, 0, 0xA8, 0, 8, 0, 4, 1 };
    static const unsigned char laterZero[] = { 2, 0, 0xA8, 0, 0, 0, 4, 1 };
    static const unsigned char initialRepeat[] = { 1, 0, 0xA8, 0, 0, 0, 4, 1 };
    static const unsigned char explicitOffset[] = { 1, 0, 0xA8, 0, 8, 1, 4, 1 };
    static const unsigned char laterRepeat[] = { 2, 0, 0x98, 0, 8, 4, 0, 0x84 };
    static const unsigned char laterZeroLiteralRepeat[] = { 3, 0, 0x98, 0, 0, 4, 0, 0x84, 0x10 };
    static const struct {
        const char* name;
        unsigned prefixSize;
        unsigned litSize;
        const unsigned char* sequences;
        size_t seqSize;
        size_t expectedSize;  /* zero means corruption_detected is expected */
        unsigned char expectedByte;
    } cases[] = {
        { "first zero offset", 0, 8, firstZero, sizeof(firstZero), 0, 0 },
        { "later zero offset", 8, 0, laterZero, sizeof(laterZero), 0, 0 },
        { "initial repeat", 8, 0, initialRepeat, sizeof(initialRepeat), 16, 'P' },
        { "explicit offset", 0, 8, explicitOffset, sizeof(explicitOffset), 16, 'A' },
        { "later repeat", 0, 16, laterRepeat, sizeof(laterRepeat), 32, 'A' },
        { "later zero-literal repeat", 8, 0, laterZeroLiteralRepeat,
          sizeof(laterZeroLiteralRepeat), 32, 'P' }
    };
    unsigned char frame[128];
    unsigned char output[128];
    unsigned version;
    size_t c;
    unsigned pattern;
    int failed = 0;

    /* The file-level 0-to-8 normalization makes this start at 1 or 2. */
    for (version = ZSTD_LEGACY_SUPPORT; version <= 2; ++version) {
        for (c = 0; c < sizeof(cases) / sizeof(cases[0]); ++c) {
            size_t const frameSize = buildLegacyOffsetFrame(frame, sizeof(frame), version,
                    cases[c].prefixSize, cases[c].litSize,
                    cases[c].sequences, cases[c].seqSize);
            if (frameSize == 0) {
                DISPLAY("ERROR: v0.%u %s exceeds tiny frame builder limits\n",
                        version, cases[c].name);
                return 1;
            }
            for (pattern = 0; pattern < 2; ++pattern) {
                size_t ret;
                size_t i;
                memset(output, pattern ? 0xDE : 0xA5, sizeof(output));
                ret = ZSTD_decompress(output, sizeof(output), frame, frameSize);
                if (cases[c].expectedSize == 0) {
                    if (ZSTD_getErrorCode(ret) != ZSTD_error_corruption_detected) {
                        DISPLAY("ERROR: v0.%u %s accepted: %s (%zu)\n",
                                version, cases[c].name, ZSTD_getErrorName(ret), ret);
                        failed = 1;
                    }
                    continue;
                }
                if (ret != cases[c].expectedSize) {
                    DISPLAY("ERROR: v0.%u %s: %s (%zu)\n",
                            version, cases[c].name, ZSTD_getErrorName(ret), ret);
                    failed = 1;
                    continue;
                }
                for (i = 0; i < ret; ++i) {
                    if (output[i] != cases[c].expectedByte) {
                        DISPLAY("ERROR: v0.%u %s: wrong output at %zu\n",
                                version, cases[c].name, i);
                        failed = 1;
                        break;
                    }
                }
            }
        }
    }
    if (failed) return 1;
    DISPLAY("Legacy zero-offset checks OK\n");
#endif
    return 0;
}

#if (ZSTD_LEGACY_SUPPORT <= 7)
/* All these formats have a 128-KB decoded block limit. The three-byte
 * block-size field can represent more, so test that oversized blocks are
 * rejected by size inspection and by the decoder. */
#define LEGACY_BLOCK_LIMIT (128U * 1024U)

static size_t buildLegacyBlockFrame(unsigned char* dst, unsigned version,
                                    unsigned type, size_t blockSize)
{
    size_t const headerSize = version < 4 ? 4 : version == 7 ? 6 : 5;
    size_t const payloadSize = type == 2 ? 1 : blockSize;
    if (version == 1) {
        dst[0] = 0xFD; dst[1] = 0x2F; dst[2] = 0xB5; dst[3] = 0x1E;
    } else {
        dst[0] = (unsigned char)(0x20 + version);
        dst[1] = 0xB5; dst[2] = 0x2F; dst[3] = 0xFD;
    }
    if (version >= 4) dst[4] = version == 6 ? 5 : 0;
    if (version == 7) dst[5] = 0x38; /* 128-KB window, unknown content size */
    dst[headerSize] = (unsigned char)((type << 6) | ((blockSize >> 16) & 7));
    dst[headerSize + 1] = (unsigned char)(blockSize >> 8);
    dst[headerSize + 2] = (unsigned char)blockSize;
    memset(dst + headerSize + 3, 'X', payloadSize);
    dst[headerSize + 3 + payloadSize] = 0xC0;
    dst[headerSize + 4 + payloadSize] = 0;
    dst[headerSize + 5 + payloadSize] = 0;
    return headerSize + 6 + payloadSize;
}
#endif

static int testLegacyBlockBounds(void)
{
#if (ZSTD_LEGACY_SUPPORT <= 7)
    size_t const sizes[] = { LEGACY_BLOCK_LIMIT - 1, LEGACY_BLOCK_LIMIT,
                            LEGACY_BLOCK_LIMIT + 1, 2 * LEGACY_BLOCK_LIMIT, 524287 };
    unsigned char* const src = (unsigned char*)malloc(2 * (524287 + 12));
    unsigned char* const decoded = (unsigned char*)malloc(524287 + 1);
    unsigned version, type;
    size_t s;
    int failed = 1;
    if (src == NULL || decoded == NULL) goto cleanup;
    for (version = ZSTD_LEGACY_SUPPORT; version <= 7; ++version) {
        for (type = 0; type < 3; ++type) {
            for (s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
                size_t const size = sizes[s];
                int const reject = size > LEGACY_BLOCK_LIMIT;
                size_t const srcSize = buildLegacyBlockFrame(src, version, type, size);
                size_t const cSize = ZSTD_findFrameCompressedSize(src, srcSize);
                unsigned long long const bound = ZSTD_decompressBound(src, srcSize);
                if (reject) {
                    if (ZSTD_getErrorCode(cSize) != ZSTD_error_corruption_detected
                        || bound != ZSTD_CONTENTSIZE_ERROR) goto mismatch;
                    if (ZSTD_getErrorCode(ZSTD_decompress(decoded, 524287 + 1, src, srcSize))
                        != ZSTD_error_corruption_detected) goto mismatch;
                } else {
                    if (cSize != srcSize || bound != LEGACY_BLOCK_LIMIT) goto mismatch;
                    /* Only decode raw blocks here: the compressed payload is
                     * arbitrary 'X' bytes, and not all early versions support RLE. */
                    if (type == 1) {
                        size_t const result = ZSTD_decompress(decoded, 524287 + 1, src, srcSize);
                        if (result != size || decoded[0] != 'X'
                            || decoded[size - 1] != 'X') goto mismatch;
                    }
                }
                continue;
mismatch:
                DISPLAY("ERROR: v0.%u block type %u size %u violates block bound\n",
                        version, type, (unsigned)size);
                goto cleanup;
            }
        }
        {   size_t const first = buildLegacyBlockFrame(src, version, 1, LEGACY_BLOCK_LIMIT);
            size_t const second = buildLegacyBlockFrame(src + first, version, 1, 1);
            size_t const result = ZSTD_decompress(decoded, 524287 + 1, src, first + second);
            if (ZSTD_decompressBound(src, first + second) != 2ULL * LEGACY_BLOCK_LIMIT
                || result != LEGACY_BLOCK_LIMIT + 1) {
                DISPLAY("ERROR: v0.%u concatenated raw frames violate block bound\n", version);
                goto cleanup;
            }
            if (ZSTD_getErrorCode(ZSTD_decompress(decoded, LEGACY_BLOCK_LIMIT - 1,
                                                  src, first)) != ZSTD_error_dstSize_tooSmall) {
                DISPLAY("ERROR: v0.%u raw block accepted an undersized destination\n", version);
                goto cleanup;
            }
        }
    }
    failed = 0;
cleanup:
    free(decoded);
    free(src);
    if (failed) DISPLAY("ERROR: Legacy block-size bound regression\n");
    return failed;
#else
    return 0;
#endif
}

#if (ZSTD_LEGACY_SUPPORT <= 4)
static size_t buildLegacyRawLiteralsFrame(unsigned char* dst, unsigned version,
                                          size_t litSize, unsigned extraDump)
{
    size_t const headerSize = version < 4 ? 4 : 5;
    size_t const blockSize = litSize + 10 + extraDump;
    size_t const frameSize = buildLegacyBlockFrame(dst, version, 0, blockSize);
    unsigned char* const block = dst + headerSize + 3;
    unsigned char* seq = block + 3 + litSize;
    size_t i;
    block[0] = (unsigned char)((litSize << 2) | 1);
    block[1] = (unsigned char)(litSize >> 6);
    block[2] = (unsigned char)(litSize >> 14);
    for (i = 0; i < litSize; ++i) block[3 + i] = (unsigned char)('A' + i);
    seq[0] = 0; seq[1] = 0; /* no sequences */
    seq[2] = 0x54;         /* raw LL/OF/ML tables */
    seq[3] = (unsigned char)extraDump;
    if (extraDump) { seq[4] = 0; ++seq; }
    seq[4] = 0; seq[5] = 0; seq[6] = 4; /* 18 initial-state bits */
    return frameSize;
}
#endif

static int testLegacyRawLiteralOffsets(void)
{
#if (ZSTD_LEGACY_SUPPORT <= 4)
    unsigned version;
    size_t const sizes[] = { 1, 4, 8, 16 };
    unsigned char frame[64];
    unsigned char decoded[32];
    unsigned char expected[32];
    for (version = ZSTD_LEGACY_SUPPORT < 2 ? 2 : ZSTD_LEGACY_SUPPORT; version <= 4; ++version) {
        unsigned extraDump;
        size_t s;
        for (extraDump = 0; extraDump <= 1; ++extraDump) {
            for (s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
                size_t const litSize = sizes[s];
                size_t const frameSize = buildLegacyRawLiteralsFrame(frame, version, litSize, extraDump);
                size_t i;
                size_t result;
                for (i = 0; i < litSize; ++i) expected[i] = (unsigned char)('A' + i);
                result = ZSTD_decompress(decoded, sizeof(decoded), frame, frameSize);
                if (result != litSize || memcmp(decoded, expected, litSize) != 0) {
                    DISPLAY("ERROR: v0.%u raw literals size %u, extra dump %u\n",
                            version, (unsigned)litSize, extraDump);
                    return 1;
                }
                /* A declared literal payload extending past the block must
                 * still fail before the temporary-buffer copy. */
                {   size_t const headerSize = version < 4 ? 4 : 5;
                    size_t const badLitSize = litSize + 8 + extraDump;
                    frame[headerSize + 3] = (unsigned char)((badLitSize << 2) | 1);
                    frame[headerSize + 4] = (unsigned char)(badLitSize >> 6);
                    frame[headerSize + 5] = (unsigned char)(badLitSize >> 14);
                    result = ZSTD_decompress(decoded, sizeof(decoded), frame, frameSize);
                    if (ZSTD_getErrorCode(result) != ZSTD_error_corruption_detected) {
                        DISPLAY("ERROR: v0.%u accepted truncated raw literals\n", version);
                        return 1;
                    }
                }
            }
        }
    }
#endif
    return 0;
}

#if (ZSTD_LEGACY_SUPPORT <= 5)
/* Build a v0.4 or v0.5 frame with windowLog 11 (2 KB), and its decoded content :
 * a raw block of prefixSize bytes, then a compressed block whose only sequence
 * copies 4 bytes from offset 1000, inside the raw block, after 500 literals.
 * It ends with 16 literals: the one-shot decoder wants room after the last match.
 * The streaming decoder wraps its output buffer between the two blocks. */
static size_t buildWrapFrame(unsigned version, unsigned char* dst, unsigned char* expected,
                             size_t* expectedSize, unsigned prefixSize)
{
    /* Sequence section: nbSeq 1 (LE16 in v0.4), then RLE LL/offset/ML tables
     * (0xA8 in v0.4, 0x54 in v0.5) and the dumps.
     * The dumps hold litLength 500: 255, then LE24 500 (v0.4) or LE16 500<<1 (v0.5).
     * Table symbols: LL 63 (read the dumps), offset code 10 (512 + 9 bits), ML 0 (MINMATCH).
     * Bitstream: the 9 offset bits (1000 - 512) under the stop bit. */
    static const unsigned char sequencesV04[] = { 1, 0, 0xA8, 4, 255, 0xF4, 0x01, 0, 63, 10, 0, 0xE8, 0x03 };
    static const unsigned char sequencesV05[] = { 1, 0x54, 3, 255, 0xE8, 0x03, 63, 10, 0, 0xE8, 0x03 };
    const unsigned char* const sequences = (version == 4) ? sequencesV04 : sequencesV05;
    size_t const seqSize = (version == 4) ? sizeof(sequencesV04) : sizeof(sequencesV05);
    unsigned const litLength = 500;
    unsigned const litSize = litLength + 16;
    size_t const blockSize = ((version == 4) ? 3 : 2) + litSize + seqSize;
    unsigned char* op = expected + prefixSize;
    unsigned char* lits;
    size_t pos = 0;
    unsigned i;
    dst[pos++] = (unsigned char)(0x20 + version);  /* magic */
    dst[pos++] = 0xB5; dst[pos++] = 0x2F; dst[pos++] = 0xFD;
    dst[pos++] = 0;  /* windowLog 11 */
    dst[pos++] = (unsigned char)(0x40 | (prefixSize >> 16));  /* raw block */
    dst[pos++] = (unsigned char)(prefixSize >> 8);
    dst[pos++] = (unsigned char)prefixSize;
    for (i = 0; i < prefixSize; i++) expected[i] = dst[pos++] = (unsigned char)i;
    dst[pos++] = (unsigned char)(blockSize >> 16);  /* compressed block */
    dst[pos++] = (unsigned char)(blockSize >> 8);
    dst[pos++] = (unsigned char)blockSize;
    if (version == 4) {  /* raw literals: LE24 (litSize << 2) | 1 */
        dst[pos++] = (unsigned char)((litSize << 2) | 1);
        dst[pos++] = (unsigned char)(litSize >> 6);
        dst[pos++] = (unsigned char)(litSize >> 14);
    } else {  /* raw literals, 2-byte header */
        dst[pos++] = (unsigned char)(0xA0 | (litSize >> 8));
        dst[pos++] = (unsigned char)litSize;
    }
    lits = dst + pos;
    for (i = 0; i < litSize; i++) lits[i] = (unsigned char)(i * 7 + 3);  /* differ from the raw block */
    pos += litSize;
    memcpy(dst + pos, sequences, seqSize);
    pos += seqSize;
    dst[pos++] = 0xC0; dst[pos++] = 0; dst[pos++] = 0;  /* end of frame */

    memcpy(op, lits, litLength);
    op += litLength;
    for (i = 0; i < 4; i++, op++) *op = op[-1000];
    memcpy(op, lits + litLength, litSize - litLength);
    op += litSize - litLength;
    *expectedSize = (size_t)(op - expected);
    return pos;
}

static int testStreamingWrap(void)
{
    /* 600: the second block overwrites history that its match still reads
     *      (#4553 in v0.5, the same flaw in v0.4).
     * 2048: the raw block fills the window, and the v0.5 streaming decoder used to
     *       keep no room for the next block (regression from the #4553 fix). */
    static const unsigned prefixSizes[] = { 600, 2048 };
    unsigned char frame[3000];
    unsigned char expected[3000];
    unsigned version;
    size_t i;
    for (version = (ZSTD_LEGACY_SUPPORT < 4) ? 4 : ZSTD_LEGACY_SUPPORT; version <= 5; ++version) {
        for (i = 0; i < sizeof(prefixSizes) / sizeof(prefixSizes[0]); ++i) {
            size_t expectedSize;
            size_t const frameSize = buildWrapFrame(version, frame, expected, &expectedSize, prefixSizes[i]);
            DISPLAY("v0.%u streaming wrap, %u-byte first block\n", version, prefixSizes[i]);
            if (testSimpleAPI((const char*)frame, frameSize, (const char*)expected, expectedSize)) return 1;
            if (testStreamingAPI((const char*)frame, frameSize, (const char*)expected, expectedSize)) return 1;
        }
    }
    return 0;
}
#endif

int main(void)
{
    size_t const blockSize = strlen(BLOCK);
    char* const compressed = malloc(ALL_FRAMES_SIZE);
    /* the streaming API can only replay the subset of frames for which a
     * legacy streaming decoder exists : it gets a buffer of its own, so that
     * each buffer keeps matching the size recorded next to it */
    char* const streamable = malloc(ALL_FRAMES_SIZE);
    char* expected = NULL;
    size_t compressedSize = 0;
    size_t streamableSize = 0;
    size_t expectedSize = 0;
    unsigned nbFrames = 0;
    unsigned nbStreamFrames = 0;
    int result = 1;

    do {
        if (compressed == NULL || streamable == NULL) {
            DISPLAY("ERROR: Not enough memory!\n");
            break;
        }
        nbFrames = buildTestFrames(compressed, &compressedSize, 1);
        nbStreamFrames = buildTestFrames(streamable, &streamableSize, OLDEST_STREAMABLE_VERSION);
        DISPLAY("Testing %u frames, from format v0.%i upward\n", nbFrames, ZSTD_LEGACY_SUPPORT);

        expectedSize = blockSize * nbFrames;
        expected = malloc(expectedSize);
        if (expected == NULL) {
            DISPLAY("ERROR: Not enough memory!\n");
            break;
        }
        {   unsigned u;
            for (u = 0; u < nbFrames; u++)
                memcpy(expected + (u * blockSize), BLOCK, blockSize);
        }

        if (testSimpleAPI(compressed, compressedSize, expected, expectedSize)) break;
        if (testFrameDecoding(compressed, compressedSize, expectedSize)) break;
        if (testDecompressBoundConcatenation(compressed, compressedSize)) break;
        /* all blocks being identical, the first @nbStreamFrames ones
         * are what the streaming subset must decode to */
        if (testStreamingAPI(streamable, streamableSize,
                             expected, blockSize * nbStreamFrames)) break;
        if (testLegacyDictionaries()) break;
#if (ZSTD_LEGACY_SUPPORT <= 7)
        if (testMultipleDDicts()) break;
#endif
        if (testLegacyZeroOffsets()) break;
        if (testLegacyBlockBounds()) break;
        if (testLegacyRawLiteralOffsets()) break;
#if (ZSTD_LEGACY_SUPPORT <= 5)
        if (testStreamingWrap()) break;
#endif
        result = 0;
    } while (0);

    free(expected);
    free(streamable);
    free(compressed);
    if (result == 0) DISPLAY("OK\n");
    return result;
}

const char* const FRAME_V01 =
    "\xFD\x2F\xB5\x1E\x00\x00\xB3\x00\x00\x9D\x00\xD8\x1F\xB0\x01\x10"
    "\x00\x00\x00\xA0\xCA\x4C\xCF\x43\xDF\xF9\xF8\x7B\x7F\xFE\x3F\xDF"
    "\xDD\xDF\xC3\x86\x55\x63\x3A\x68\x70\x44\x44\x08\x1F\x00\x1D\x00"
    "\x1D\x00\x44\x21\x80\x32\xAD\x75\x6F\xB1\x6B\x3B\x7A\x3F\x77\xAE"
    "\x8F\x95\x4A\x73\xEC\xCF\x73\x0C\x07\x9A\x9E\xF0\x5E\xB4\xCB\x94"
    "\x06\x99\xE6\x3E\x28\xF0\x80\x42\xA9\x1A\x2B\x0E\xDF\xC9\x06\x82"
    "\xB6\x56\x72\x98\x49\xB2\xBE\xEE\xCD\x25\xA1\xAC\x86\x01\x99\xD4"
    "\x28\x05\x9F\xC8\xF9\x1D\x90\x30\x6B\x18\x08\x9B\xA0\xF5\x12\xC9"
    "\x5F\x4B\x80\x37\xAD\x14\x5A\xD2\xCD\x98\x01\xE8\x77\x03\x63\x08"
    "\xB4\xA4\x81\xD8\xE9\x24\xB2\x73\x9F\x9C\x03\x07\x52\x6A\x2F\xC2"
    "\xCE\x70\x1B\xFF\xD0\x4E\x01\x04\x00\x54\x01\x43\x80\x07\x00\xA1"
    "\x28\x3F\x20\x9C\x6A\x30\xA3\x01\xC8\x12\xC0\x00\x00";

const char* const FRAME_V02 =
    "\x22\xB5\x2F\xFD\x00\x00\xB1\x60\x03\x20\x13\x00\x1F\xB0\x01\x10"
    "\x00\x00\x00\xA0\xCA\x4C\xCF\x43\xDF\xF9\xF8\x7B\x7F\xFE\x3F\xDF"
    "\xDD\xDF\xC3\x86\x55\x63\x3A\x68\x70\x44\x44\x08\x19\x00\x1D\x00"
    "\x1E\x00\xAB\x65\x8D\x76\xE9\x32\x5A\x7D\xA3\x19\xED\xF6\x94\xB8"
    "\x12\xEC\x2E\xA3\xB9\x6C\x35\xA3\x55\x4A\xD4\xC9\x68\x56\x3B\x79"
    "\xDB\x40\xEA\x07\x52\x23\x99\x5C\x3E\xB2\xB6\xB3\x6B\xCE\x96\x18"
    "\x2A\xF3\x20\x00\x0A\xED\xED\x36\xB5\xB1\x2E\x72\xBA\x1D\xCC\x19"
    "\xED\x12\x51\x9C\x63\x0E\xE7\x5E\xC8\xB8\xCD\xF0\x39\x84\xC4\x6E"
    "\x2F\x27\x46\x8D\x90\x0C\x44\x21\x80\x32\xAD\x28\xB3\x4E\x79\xAB"
    "\x79\x8D\xDB\xCB\x85\x41\xC1\xC1\x9A\x8B\x35\xA3\x11\xE4\xAB\x48"
    "\xC0\xE5\x02\xCA\x0C\x04\x00\x54\x01\x43\x80\x07\x00\xA1\x28\x3F"
    "\x20\x9C\x6A\x30\xA3\x01\xC8\x12\xC0\x00\x00";

const char* const FRAME_V03 =
    "\x23\xB5\x2F\xFD\x00\x00\xB1\x50\x03\xE0\x12\x00\x1F\xB0\x01\x10"
    "\x00\x00\x00\xA0\xCA\x4C\xCF\x43\xDF\xF9\xF8\x7B\x7F\xFE\x3F\xDF"
    "\xDD\xDF\xC3\x86\x55\x63\x3A\x68\x70\x44\x44\x08\x19\x00\x1D\x00"
    "\x1D\x00\x6A\x59\xA3\x5D\xBA\x8C\x56\xDF\x68\x46\xBB\x3D\x25\xAE"
    "\x04\xBB\xCB\x68\x2E\x5B\xCD\x68\x95\x12\x35\x48\x26\xA3\x59\xED"
    "\xE4\x6D\x03\xA9\x1F\x48\x8D\x64\x72\xF9\xC8\xDA\xCE\xAE\x39\x5B"
    "\x62\xA8\xCC\x83\x00\x28\xB4\x0F\x59\x1B\xEB\x22\xA7\xDB\xC1\x9C"
    "\xD1\x2E\x11\xC5\x39\xE6\x70\xEE\x85\x8C\xDB\x0C\x9F\x43\x48\xEC"
    "\xF6\x72\x62\xD4\x28\x44\x21\x80\x32\xAD\x28\xB3\x4E\x79\xAB\x79"
    "\x8D\xDB\xCB\x85\x41\xC1\xC1\x9A\x8B\x35\xA3\x11\xE4\xAB\x48\xC0"
    "\xE5\x02\xCA\x05\x00\x54\x01\x43\x80\x07\x00\xA1\x28\x3F\xE0\x04"
    "\x80\x00\xA0\xC1\x8C\x06\x20\x4B\xC0\x00\x00";

const char* const FRAME_V04 =
    "\x24\xB5\x2F\xFD\x00\x00\x00\xBB\xB0\x02\xC0\x10\x00\x1E\xB0\x01"
    "\x02\x00\x00\x80\x00\xE8\x92\x34\x12\x97\xC8\xDF\xE9\xF3\xEF\x53"
    "\xEA\x1D\x27\x4F\x0C\x44\x90\x0C\x8D\xF1\xB4\x89\x17\x00\x18\x00"
    "\x18\x00\x3F\xE6\xE2\xE3\x74\xD6\xEC\xC9\x4A\xE0\x71\x71\x42\x3E"
    "\x64\x4F\x6A\x45\x4E\x78\xEC\x49\x03\x3F\xC6\x80\xAB\x8F\x75\x5E"
    "\x6F\x2E\x3E\x7E\xC6\xDC\x45\x69\x6C\xC5\xFD\xC7\x40\xB8\x84\x8A"
    "\x01\xEB\xA8\xD1\x40\x39\x90\x4C\x64\xF8\xEB\x53\xE6\x18\x0B\x67"
    "\x12\xAD\xB8\x99\xB3\x5A\x6F\x8A\x19\x03\x01\x50\x67\x56\xF5\x9F"
    "\x35\x84\x60\xA0\x60\x91\xC9\x0A\xDC\xAB\xAB\xE0\xE2\x81\xFA\xCF"
    "\xC6\xBA\x01\x0E\x00\x54\x00\x00\x19\x00\x00\x54\x14\x00\x24\x24"
    "\x04\xFE\x04\x84\x4E\x41\x00\x27\xE2\x02\xC4\xB1\x00\xD2\x51\x00"
    "\x79\x58\x41\x28\x00\xE0\x0C\x01\x68\x65\x00\x04\x13\x0C\xDA\x0C"
    "\x80\x22\x06\xC0\x00\x00";

const char* const FRAME_V05 =
    "\x25\xB5\x2F\xFD\x00\x00\x00\xAD\x12\xB0\x7D\x1E\xB0\x01\x02\x00"
    "\x00\x80\x00\xE8\x92\x34\x12\x97\xC8\xDF\xE9\xF3\xEF\x53\xEA\x1D"
    "\x27\x4F\x0C\x44\x90\x0C\x8D\xF1\xB4\x89\x03\x01\x50\x67\x56\xF5"
    "\x9F\x35\x84\x60\xA0\x60\x91\xC9\x0A\xDC\xAB\xAB\xE0\xE2\x81\xFA"
    "\xCF\xC6\xBA\xEB\xA8\xD1\x40\x39\x90\x4C\x64\xF8\xEB\x53\xE6\x18"
    "\x0B\x67\x12\xAD\xB8\x99\xB3\x5A\x6F\x8A\xF9\x63\x0C\xB8\xFA\x58"
    "\xE7\xF5\xE6\xE2\xE3\x67\xCC\x5D\x94\xC6\x56\xDC\x7F\x0C\x84\x4B"
    "\xA8\xF8\x63\x2E\x3E\x4E\x67\xCD\x9E\xAC\x04\x1E\x17\x27\xE4\x43"
    "\xF6\xA4\x56\xE4\x84\xC7\x9E\x34\x0E\x00\x00\x32\x40\x80\xA8\x00"
    "\x01\x49\x81\xE0\x3C\x01\x29\x1D\x00\x87\xCE\x80\x75\x08\x80\x72"
    "\x24\x00\x7B\x52\x00\x94\x00\x20\xCC\x01\x86\xD2\x00\x81\x09\x83"
    "\xC1\x34\xA0\x88\x01\xC0\x00\x00";

const char* const FRAME_V06 =
    "\x26\xB5\x2F\xFD\x42\xEF\x00\x00\xA6\x12\xB0\x7D\x1E\xB0\x01\x02"
    "\x00\x00\x54\xA0\xBA\x24\x8D\xC4\x25\xF2\x77\xFA\xFC\xFB\x94\x7A"
    "\xC7\xC9\x13\x03\x11\x24\x43\x63\x3C\x6D\x22\x03\x01\x50\x67\x56"
    "\xF5\x9F\x35\x84\x60\xA0\x60\x91\xC9\x0A\xDC\xAB\xAB\xE0\xE2\x81"
    "\xFA\xCF\xC6\xBA\xEB\xA8\xD1\x40\x39\x90\x4C\x64\xF8\xEB\x53\xE6"
    "\x18\x0B\x67\x12\xAD\xB8\x99\xB3\x5A\x6F\x8A\xF9\x63\x0C\xB8\xFA"
    "\x58\xE7\xF5\xE6\xE2\xE3\x67\xCC\x5D\x94\xC6\x56\xDC\x7F\x0C\x84"
    "\x4B\xA8\xF8\x63\x2E\x3E\x4E\x67\xCD\x9E\xAC\x04\x1E\x17\x27\xE4"
    "\x43\xF6\xA4\x56\xE4\x84\xC7\x9E\x34\x0E\x00\x35\x0B\x71\xB5\xC0"
    "\x2A\x5C\x26\x94\x22\x20\x8B\x4C\x8D\x13\x47\x58\x67\x15\x6C\xF1"
    "\x1C\x4B\x54\x10\x9D\x31\x50\x85\x4B\x54\x0E\x01\x4B\x3D\x01\xC0"
    "\x00\x00";

const char* const FRAME_V07 =
    "\x27\xB5\x2F\xFD\x20\xEF\x00\x00\xA6\x12\xE4\x84\x1F\xB0\x01\x10"
    "\x00\x00\x00\x35\x59\xA6\xE7\xA1\xEF\x7C\xFC\xBD\x3F\xFF\x9F\xEF"
    "\xEE\xEF\x61\xC3\xAA\x31\x1D\x34\x38\x22\x22\x04\x44\x21\x80\x32"
    "\xAD\x28\xF3\xD6\x28\x0C\x0A\x0E\xD6\x5C\xAC\x19\x8D\x20\x5F\x45"
    "\x02\x2E\x17\x50\x66\x6D\xAC\x8B\x9C\x6E\x07\x73\x46\xBB\x44\x14"
    "\xE7\x98\xC3\xB9\x17\x32\x6E\x33\x7C\x0E\x21\xB1\xDB\xCB\x89\x51"
    "\x23\x34\xAB\x9D\xBC\x6D\x20\xF5\x03\xA9\x91\x4C\x2E\x1F\x59\xDB"
    "\xD9\x35\x67\x4B\x0C\x95\x79\x10\x00\x85\xA6\x96\x95\x2E\xDF\x78"
    "\x7B\x4A\x5C\x09\x76\x97\xD1\x5C\x96\x12\x75\x35\xA3\x55\x4A\xD4"
    "\x0B\x00\x35\x0B\x71\xB5\xC0\x2A\x5C\xE6\x08\x45\xF1\x39\x43\xF1"
    "\x1C\x4B\x54\x10\x9D\x31\x50\x85\x4B\x54\x0E\x01\x4B\x3D\x01\xC0"
    "\x00\x00";

const char* const FRAME_V08 =
    "\x28\xB5\x2F\xFD\x24\xEF\x35\x05\x00\x92\x0B\x21\x1F\xB0\x01\x10"
    "\x00\x00\x00\x35\x59\xA6\xE7\xA1\xEF\x7C\xFC\xBD\x3F\xFF\x9F\xEF"
    "\xEE\xEF\x61\xC3\xAA\x31\x1D\x34\x38\x22\x22\x04\x44\x21\x80\x32"
    "\xAD\x28\xF3\xD6\x28\x0C\x0A\x0E\xD6\x5C\xAC\x19\x8D\x20\x5F\x45"
    "\x02\x2E\x17\x50\x66\x6D\xAC\x8B\x9C\x6E\x07\x73\x46\xBB\x44\x14"
    "\xE7\x98\xC3\xB9\x17\x32\x6E\x33\x7C\x0E\x21\xB1\xDB\xCB\x89\x51"
    "\x23\x34\xAB\x9D\xBC\x6D\x20\xF5\x03\xA9\x91\x4C\x2E\x1F\x59\xDB"
    "\xD9\x35\x67\x4B\x0C\x95\x79\x10\x00\x85\xA6\x96\x95\x2E\xDF\x78"
    "\x7B\x4A\x5C\x09\x76\x97\xD1\x5C\x96\x12\x75\x35\xA3\x55\x4A\xD4"
    "\x0B\x00\x35\x0B\x71\xB5\xC0\x2A\x5C\xE6\x08\x45\xF1\x39\x43\xF1"
    "\x1C\x4B\x54\x10\x9D\x31\x50\x85\x4B\x54\x0E\x01\x4B\x3D\x01\xD2"
    "\x2F\x21\x80";


const char* const BLOCK =
    "snowden is snowed in / he's now then in his snow den / when does the snow end?\n"
    "goodbye little dog / you dug some holes in your day / they'll be hard to fill.\n"
    "when life shuts a door, / just open it. it’s a door. / that is how doors work.\n";
