/*
 * librdkafka - Apache Kafka C library
 *
 * Copyright (c) 2020-2022, Magnus Edenhill
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "test.h"

#include "rdkafka.h"

#include "../src/rdkafka_proto.h"
#include "../src/rdunittest.h"

#include <stdarg.h>


/**
 * @name Connecting to two different clusters should emit warning.
 *
 */

static void
log_cb(const rd_kafka_t *rk, int level, const char *fac, const char *buf) {
        rd_atomic32_t *log_cntp = rd_kafka_opaque(rk);
        rd_bool_t matched       = !strcmp(fac, "CLUSTERID") &&
                            strstr(buf, "reports different ClusterId");

        TEST_SAY("%sLog: %s level %d fac %s: %s\n", matched ? _C_GRN : "",
                 rd_kafka_name(rk), level, fac, buf);

        if (matched)
                rd_atomic32_add(log_cntp, 1);
}


static void do_test_different_clusterid_warning(void) {
        rd_kafka_mock_cluster_t *cluster_a, *cluster_b;
        const char *bootstraps_a, *bootstraps_b;
        size_t bs_size;
        char *bootstraps;
        rd_kafka_t *rk;
        rd_kafka_conf_t *conf;
        rd_atomic32_t log_cnt;
        int cnt = 0;

        SUB_TEST_QUICK();

        /* Create two clusters */
        cluster_a = test_mock_cluster_new(1, &bootstraps_a);
        cluster_b = test_mock_cluster_new(1, &bootstraps_b);
        rd_kafka_mock_broker_set_down(cluster_b, 1);

        test_conf_init(&conf, NULL, 10);

        /* Combine bootstraps from both clusters */
        bs_size    = strlen(bootstraps_a) + strlen(bootstraps_b) + 2;
        bootstraps = malloc(bs_size);
        rd_snprintf(bootstraps, bs_size, "%s,%s", bootstraps_a, bootstraps_b);
        test_conf_set(conf, "bootstrap.servers", bootstraps);
        free(bootstraps);

        rd_atomic32_init(&log_cnt, 0);
        rd_kafka_conf_set_log_cb(conf, log_cb);
        rd_kafka_conf_set_opaque(conf, &log_cnt);

        rk = test_create_handle(RD_KAFKA_PRODUCER, conf);


        while (rd_atomic32_get(&log_cnt) == 0) {
                const rd_kafka_metadata_t *md;

                /* After 3 seconds bring down cluster a and bring up
                 * cluster b, this is to force the client to connect to
                 * the other cluster. */
                if (cnt == 3) {
                        rd_kafka_mock_broker_set_down(cluster_a, 1);
                        rd_kafka_mock_broker_set_up(cluster_b, 1);
                }

                if (!rd_kafka_metadata(rk, 1, NULL, &md, 1000))
                        rd_kafka_metadata_destroy(md);
                rd_sleep(1);

                cnt++;
        }


        rd_kafka_destroy(rk);
        test_mock_cluster_destroy(cluster_a);
        test_mock_cluster_destroy(cluster_b);

        SUB_TEST_PASS();
}


/**
 * @name Destroying the client while rd_kafka_clusterid() is blocked
 *       must make it return immediately.
 */

struct clusterid_thread_arg {
        rd_kafka_t *rk;
        rd_atomic32_t started;
        rd_atomic32_t done;
        char *clusterid;
        int64_t elapsed_us;
};

static int clusterid_thread_main(void *p) {
        struct clusterid_thread_arg *arg = p;
        int64_t ts_start                 = test_clock();

        rd_atomic32_set(&arg->started, 1);
        arg->clusterid  = rd_kafka_clusterid(arg->rk, 60 * 1000);
        arg->elapsed_us = test_clock() - ts_start;
        rd_atomic32_set(&arg->done, 1);
        return 0;
}

static void do_test_destroy_during_clusterid(void) {
        rd_kafka_mock_cluster_t *mcluster;
        const char *bootstraps;
        rd_kafka_conf_t *conf;
        struct clusterid_thread_arg arg = {0};
        thrd_t thrd;
        int64_t ts_deadline;
        int ret;

        SUB_TEST_QUICK();

        rd_atomic32_init(&arg.started, 0);
        rd_atomic32_init(&arg.done, 0);

        /* Broker down: no metadata is received, so clusterid() blocks. */
        mcluster = test_mock_cluster_new(1, &bootstraps);
        rd_kafka_mock_broker_set_down(mcluster, 1);

        test_conf_init(&conf, NULL, 30);
        test_conf_set(conf, "bootstrap.servers", bootstraps);
        arg.rk = test_create_handle(RD_KAFKA_PRODUCER, conf);

        if (thrd_create(&thrd, clusterid_thread_main, &arg) != thrd_success)
                TEST_FAIL("Failed to create thread");

        ts_deadline = test_clock() + 10 * 1000 * 1000;
        while (!rd_atomic32_get(&arg.started)) {
                TEST_ASSERT(test_clock() < ts_deadline,
                            "clusterid thread did not start");
                rd_usleep(10 * 1000, NULL);
        }

        /* Let the thread block in rd_kafka_clusterid(), then make sure
         * it's still blocked when destroying, so destroy is what
         * interrupts it. */
        rd_sleep(1);
        TEST_ASSERT(!rd_atomic32_get(&arg.done),
                    "rd_kafka_clusterid() returned before rd_kafka_destroy()");
        rd_kafka_destroy(arg.rk);

        if (thrd_join(thrd, &ret) != thrd_success)
                TEST_FAIL("thrd_join failed");

        TEST_SAY("rd_kafka_clusterid() returned after %.3fs\n",
                 (double)arg.elapsed_us / 1e6);
        TEST_ASSERT(!arg.clusterid, "Expected NULL clusterid, got %s",
                    arg.clusterid);
        TEST_ASSERT(arg.elapsed_us < 5 * 1000 * 1000,
                    "Expected rd_kafka_clusterid() to return right after "
                    "rd_kafka_destroy(), took %.3fs",
                    (double)arg.elapsed_us / 1e6);

        test_mock_cluster_destroy(mcluster);

        SUB_TEST_PASS();
}


int main_0121_clusterid(int argc, char **argv) {
        TEST_SKIP_MOCK_CLUSTER(0);

        do_test_different_clusterid_warning();
        do_test_destroy_during_clusterid();

        return 0;
}
