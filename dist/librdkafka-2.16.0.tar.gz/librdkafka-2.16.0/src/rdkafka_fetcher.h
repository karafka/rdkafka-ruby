/*
 * librdkafka - The Apache Kafka C/C++ library
 *
 * Copyright (c) 2022, Magnus Edenhill
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


#ifndef _RDKAFKA_FETCHER_H_
#define _RDKAFKA_FETCHER_H_


int rd_kafka_broker_fetch_toppars(rd_kafka_broker_t *rkb, rd_ts_t now);

rd_kafka_fetch_pos_t
rd_kafka_toppar_fetch_decide_next_fetch_start_pos(rd_kafka_toppar_t *rktp);

rd_ts_t rd_kafka_toppar_fetch_decide(rd_kafka_toppar_t *rktp,
                                     rd_kafka_broker_t *rkb,
                                     int force_remove);

void rd_kafka_broker_share_fetch_session_leave(rd_kafka_broker_t *rkb,
                                               rd_kafka_op_t *rko_orig,
                                               rd_ts_t now);
void rd_kafka_broker_share_fetch_session_clear(rd_kafka_broker_t *rkb);
void rd_kafka_broker_session_remove_partition_from_toppars_in_session(
    rd_kafka_broker_t *rkb,
    rd_kafka_toppar_t *rktp);
void rd_kafka_broker_share_rpc(rd_kafka_broker_t *rkb,
                               rd_kafka_op_t *rko_orig,
                               rd_ts_t now);
void rd_kafka_share_filter_acquired_records_and_update_ack_type(
    rd_kafka_q_t *temp_fetchq,
    rd_list_t *filtered_msgs,
    const int64_t *FirstOffsets,
    const int64_t *LastOffsets,
    const int16_t *DeliveryCounts,
    int32_t AcquiredRecordsArrayCnt);


#endif /* _RDKAFKA_FETCHER_H_ */
